package app;

import java.util.Date;
import java.util.Random;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.game.*;

import com.pyy.MainMIDlet;

import util.*;

import util.gra.*;

import util.role.Anb;

import util.role.GameObj;
import util.role.Man;
import util.role.Map;
import util.role.Noelle;
import util.role.Pot;
import util.role.QQROpe;
import util.role.QQRen;
import util.role.Traveler;

public class Game extends GameCanvas implements Runnable {
	private Sprite currentSP;
	PM pm = new PM();
	//PAUSE pau = new PAUSE();
	MainMIDlet mi;
	int role_index=0;
	private Noelle noelle = new Noelle();
	private Traveler traveler = new Traveler();
	Man man;
	Pot p1,p2,p3;
	private LayerManager lm = new LayerManager();
	Anb anb = new Anb();
	public static int x,y;
	Map m = new Map();
	public boolean RUN = true;
	QQRen q1 = new QQRen(580,560);
	QQRen q2 = new QQRen(560,540);
	QQRen q3 = new QQRen(480,440);
	void initItem(){
		
		
		Pot p4 = new Pot(250,250, true);
		
		//QQRen q1 = new QQRen(250,350);
		GameOpe.ENEMY.addElement(q1);
		//QQRen q2 = new QQRen(350,250);
		GameOpe.ENEMY.addElement(q2);
		GameOpe.ENEMY.addElement(q3);
		p1 = new Pot(80,90,true);
		//lm.append(q1.getSP());
		//lm.append(q2.getSP());
		q1.patrol(10);
		
		p2 = new Pot(140,90,false);
		p3 = new Pot(500,500,true);
		lm.append(p4.getPOT());
		GameOpe.ENEMY.addElement(p1);
		GameOpe.ENEMY.addElement(p2);
		GameOpe.ENEMY.addElement(p3);
		lm.append(p1.getPOT());
		lm.append(p2.getPOT());
		lm.append(p3.getPOT());
	}
	public Game(MainMIDlet mi){
		super(false);
		this.mi=mi;
		
		this.setSP(traveler);
		//currentSP = traveler.getRole();
		fx=120;
		fy=160;
		currentSP.defineReferencePixel(40, 40);
		currentSP.setRefPixelPosition(fx, fy);
		currentSP.setVisible(true);
		traveler.setDir(Man.NORTH);
		this.setFullScreenMode(true);
		x=540;
		y=540;
		//
		lm.setViewWindow(x,y, this.getWidth(), this.getHeight());
	
		//������ϷԪ�غ�NPC
		initItem();
		//���ӵ�ͼ
		lm.append(m.tl);
		//�ƶ�
		q1.startPatrol();
		
	}
	int fx,fy;
	public void setSP(Man m){
		this.man=m;
		currentSP = ((Man) m).getRole();
		fx=120;
		fy=160;
		
		currentSP.setRefPixelPosition(fx, fy);
		m.setDir(Man.NORTH);
	}
	public void start(){
	RUN=true;
	new Thread(this).start();
	new i1().start();
	new ts().start();
	}
	public void stop(){
		RUN=false;
	}
	public void draw(Graphics g){
		g.setColor(255, 255, 255);
		g.fillRect(0, 0, ScreenOpe.sx, ScreenOpe.sy);
		q1.getSP().paint(g);
		
		lm.setViewWindow(x, y, this.getWidth(), this.getHeight());
		
		this.lm.paint(g, 0, 0);
		
		pm.pm.paint(g);
		
		
		if(traveler.isA()){
			traveler.getWind().paint(g);
		}
		if(anb.arr){
			anb.arrow.paint(g);
		}
		
		if(anb.isSkill()){
			anb.rabbit.paint(g);
		}
		
		for(int i=0;i<GameOpe.ENEMY.size();i++){
			Object o = GameOpe.ENEMY.elementAt(i);
			if(o instanceof QQRen){
				
				QQRen qqr = (QQRen) o;
				//System.out.println(qqr.getSP().getX());
				qqr.getSP().paint(g);
			}
		}
		this.currentSP.paint(g);
		
		
		this.flushGraphics();
	}
	
	class ept extends Thread{
		Graphics gr;
		ept(Graphics gr){
			this.gr=gr;
		}
		public void run(){
			for(int i=0;i<GameOpe.ENEMY.size();i++){
				GameObj go = (GameObj)GameOpe.ENEMY.elementAt(i);
				if(go instanceof QQRen){
					
					QQRen qqr = (QQRen)go;
					if(qqr.isPaintable()){
					qqr.getSP().paint(gr);
					}
				}else if(go instanceof Pot){
					Pot p = (Pot)go;
					p.getPOT().paint(gr);
				}
			}
		}
	}
	/**
	 * dont use this
	 */
	void unusedBlock(){
		/*run*/{
		for(int i=0;i<GameOpe.ENEMY.size();i++){
			GameObj go = (GameObj) GameOpe.ENEMY.elementAt(i);
			if(go instanceof QQRen){
				QQRen qqr = (QQRen) go;
			}
		}
		}
	}
	public void run() {
		Graphics g = this.getGraphics();
		QQROpe.addQQRenArea(120, 120, 200, 300, 5, 4);
		while(RUN){
			input();
			//System.out.println(x+","+y);
			draw(g);
			
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	void input(){
		int c = this.getKeyStates();
		if((c&UP_PRESSED)!=0){
			up();
		}else if((c&DOWN_PRESSED)!=0){
			down();
		}/*else if((c&FIRE_PRESSED)!=0){
			//traveler.attack();
			man.attack();
		}*/
	}
	void i1(){
		int c = this.getKeyStates();
		if((c&LEFT_PRESSED)!=0){
			left();
		}else if((c&RIGHT_PRESSED)!=0){
			right();
		}else if((c&GAME_A_PRESSED)!=0){
			ga();
		}/*else if((c&GAME_B_PRESSED)!=0){
			role();
		}*/
	}
	final void fire(){
		
	}
	final void ga(){
		/*if(man instanceof Traveler){
		traveler.skill();
		}else if(man instanceof Anb){
			anb.skill();
		}*/
		man.skill();
	}
	final void role(){
		if(role_index==2){
			role_index=0;
			this.setSP(traveler);
		}else if(role_index==0){
			role_index=1;
			this.setSP(anb);
		}else if(role_index==1){
			role_index=2;
			this.setSP(noelle);
		}
	}
	final void left(){
		if(x>0){
		man.setDir(Man.WEST);
		//traveler.walk();
		x-=Man.SPEED;
		for(int i=0;i<GameOpe.ENEMY.size();i++){
			if(GameOpe.ENEMY.elementAt(i) instanceof QQRen){
				//System.out.println("�ƶ�");
				QQRen qqr = (QQRen) GameOpe.ENEMY.elementAt(i);
				qqr.setPos(qqr.getSX()+Man.SPEED, qqr.getSY());
			}
		}
		if(anb.isSkill()){
			anb.rabbit.setRefPixelPosition(anb.rabbit.getRefPixelX()+Man.SPEED, anb.rabbit.getRefPixelY());
		}
		}
	}
	final void right(){
		if(x<5000-120){
		man.setDir(Man.EAST);
		//traveler.walk();
		x+=Man.SPEED;
for(int i=0;i<GameOpe.ENEMY.size();i++){
	if(GameOpe.ENEMY.elementAt(i) instanceof QQRen){
		QQRen qqr = (QQRen) GameOpe.ENEMY.elementAt(i);
		qqr.setPos(qqr.getSX()-Man.SPEED, qqr.getSY());
	}
		}
if(anb.isSkill()){
	anb.rabbit.setRefPixelPosition(anb.rabbit.getRefPixelX()-Man.SPEED, anb.rabbit.getRefPixelY());
}
		}
	}
	final void up(){
		if(y>0){
		man.setDir(Man.NORTH);
		//traveler.walk();
		y-=Man.SPEED;
for(int i=0;i<GameOpe.ENEMY.size();i++){
			if(GameOpe.ENEMY.elementAt(i) instanceof QQRen){
				QQRen qqr = (QQRen) GameOpe.ENEMY.elementAt(i);
				qqr.setPos(qqr.getSX(), qqr.getSY()+Man.SPEED);
			}
		}
if(anb.isSkill()){
	anb.rabbit.setRefPixelPosition(anb.rabbit.getRefPixelX(), anb.rabbit.getRefPixelY()+Man.SPEED);
}
		}
	}
	final void down(){
		if(y<5000-160){
		man.setDir(Man.SOUTH);
		//traveler.walk();
		y+=Man.SPEED;
for(int i=0;i<GameOpe.ENEMY.size();i++){
	if(GameOpe.ENEMY.elementAt(i) instanceof QQRen){
		QQRen qqr = (QQRen) GameOpe.ENEMY.elementAt(i);
		qqr.setPos(qqr.getSX(), qqr.getSY()-Man.SPEED);
	}
		}
if(anb.isSkill()){
	anb.rabbit.setRefPixelPosition(anb.rabbit.getRefPixelX(), anb.rabbit.getRefPixelY()-Man.SPEED);
}
		}
	}
	
	public void keyPressed(int c){
		System.out.println(c+"����");
		if(c==-7){
			this.stop();
			mi.m();
		}else if(c==35){
			man.fly();
		}else if(c==-1||c==-2||c==-3||c==-4||c==50||c==52||c==54||c==56){
			if(man instanceof Noelle){
				noelle.notify=true;
			}
		}else if(c==42){
				kfly();
		}else if(c==57){
			role();
		}else if(c==GAME_B){
			role();
		}else if(c==53||c==-5){
			man.attack();
		}
	}
	void kfly(){
		//if(PlayerUtil.ROLE==0){
		if(man.getDir()==Man.NORTH){
			y-=Traveler.speedX;
		}else if(man.getDir()==Man.SOUTH){
		y+=Traveler.speedX;
		}else if(man.getDir()==Man.EAST){
			x+=Traveler.speedX;
		}else if(man.getDir()==Man.WEST){
			x-=Traveler.speedX;
		}
		}
		//}
	
	public void keyReleased(int c){
		System.out.println(c+"�ɿ�");
		if(c==-1||c==-2||c==-3||c==-4||c==50||c==52||c==54||c==56){
			if(man instanceof Noelle){
				noelle.stopwalk();
				noelle.notify=false;
			}
		}
	}
	long delay=10;
	private void tile(){
		if(m.switchTile){
			m.tl.setAnimatedTile(m.at1, 15);
			m.tl.setAnimatedTile(m.at2, 16);
		}else{
			m.tl.setAnimatedTile(m.at1, 16);
			m.tl.setAnimatedTile(m.at2, 15);
		}
		m.switchTile=!m.switchTile;
	}
	public void keyRepeated(int c){}
	class ts extends Thread{
		public void run(){
			while(RUN){
				tile();
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	class i1 extends Thread{
		public void run(){
			while(RUN){
				i1();
				
				try {
					Thread.sleep(delay);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	
	
}
