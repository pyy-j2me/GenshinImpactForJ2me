package app;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import com.pyy.MainMIDlet;


public class MainCanvas extends Canvas {
	
	private MainMIDlet m;
	Image imf;
	public MainCanvas(MainMIDlet m){
		this.setFullScreenMode(true);
		this.m=m;
		try{
			imf = Image.createImage("/splash/main.png");
		}catch(Exception ex){
			
		}
	}
	protected void paint(Graphics g) {
		g.drawImage(imf, 0, 0, Graphics.TOP|Graphics.LEFT);
		g.drawString("�˳�", this.getWidth(), this.getHeight(), Graphics.BOTTOM|Graphics.RIGHT);
	}
	public void keyPressed(int c){
		if(c==-5){
			g();
		}else if(c==53){
			g();
		}else if(c==-7){
			m.exit();
		}
	}
	void g(){
		m.game();
	}
	public void keyReleased(int c){
		
	}
	public void keyRepeated(int c){
		
	}

}
