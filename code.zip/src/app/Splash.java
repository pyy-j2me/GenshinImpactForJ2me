package app;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.GameCanvas;

import com.pyy.MainMIDlet;

import util.PlayerUtil;
import util.ScreenOpe;



public class Splash extends Canvas implements Runnable {
	int y=298;
	private MainMIDlet m;
	Image bg;
	Image gau;
	public Splash(MainMIDlet m){
		this.setFullScreenMode(true);
		this.m=m;
		ScreenOpe.sx=this.getWidth();
		ScreenOpe.sy=this.getHeight();
		x=0;
		try{
		bg=Image.createImage("/splash/loading.png");
		gau = Image.createImage("/splash/loadgauge/png");
		}catch(Exception ex){
			
		}
		
	}
	boolean run = true;
	public void start(){
		run=true;
		new Thread(this).start();
	}
	public void stop(){
		run=false;
	}
	public void draw(Graphics g){
		g.setColor(0,0,0);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		g.drawImage(bg, 0, 0, Graphics.TOP|Graphics.LEFT);
		g.setColor(0x00FF0000);	
		g.fillRect(0, y, x, 6);
	}
	int x;
	public void setValue(int x){
		this.x=x;
	}
	public void run() {
		while(run){
			this.repaint();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	protected void paint(Graphics arg0) {
		draw(arg0);
		
	}

}
