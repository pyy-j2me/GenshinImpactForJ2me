package com.pyy;

import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordStore;
import app.*;

import util.PlayerUtil;
import util.SS;
import util.r;
import util.rms.RMSUtil;

public class MainMIDlet extends MIDlet {
	RecordStore RMS;
	public static final String RMS$NAME=
			"gamecfg";
	public MainMIDlet() {
		// TODO Auto-generated constructor stub
	}
	public void exit(){
		System.gc();
		try {
			this.destroyApp(false);
		} catch (MIDletStateChangeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.notifyDestroyed();
	}
	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
		// TODO Auto-generated method stub
		g.stop();
		System.gc();
		try{
			
			String level = "LEVEL="+String.valueOf(PlayerUtil.LEVEL);
			String x = "X="+String.valueOf(PlayerUtil.X);
			String y = "Y="+String.valueOf(PlayerUtil.Y);
			String food = "FOOD="+String.valueOf(PlayerUtil.FOOD_COUNT);
			String role = "YUANSHI="+String.valueOf(PlayerUtil.YUANSHI);
			RMSUtil.setString(RMS, r.LEVEL, level);
			RMSUtil.setString(RMS, r.X, x);
			RMSUtil.setString(RMS, r.Y, y);
			RMSUtil.setString(RMS, r.FOOD_COUNT, food);
			RMSUtil.setString(RMS, r.YUANSHI, role);
			
			System.out.println("�浵�ɹ�");
			
			RMS.closeRecordStore();
			//RMSUtil.delRMS("player");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	Game g = new Game(this);
	public void game(){
		g.start();
		dis.setCurrent(g);
		
	}
	protected void pauseApp() {
		// TODO Auto-generated method stub

	}
	public void m(){
		dis.setCurrent(new MainCanvas(this));
	}
	Display dis = Display.getDisplay(this);
	protected void startApp() throws MIDletStateChangeException {
		// TODO Auto-generated method stub
		Splash s = new Splash(this);
		s.start();
		dis.setCurrent(s);
		s.setValue(240);
		rms(s);
		s.stop();
		m();
	}
	void rms(Splash s){
		try{
		RMS = RecordStore.openRecordStore(RMS$NAME, false);
		System.out.println("�򿪴浵");
		RecordEnumeration re = RMS.enumerateRecords(null, null, false);
		while(re.hasNextElement()){
			String data = new String(re.nextRecord(),"UTF-8");
			int id = re.nextRecordId();
			if(data.startsWith("FOOD")){
				r.FOOD_COUNT=id;
				String[]d=SS.split(data, "=");
				PlayerUtil.FOOD_COUNT=Integer.parseInt(d[1]);
				
			}else if(data.startsWith("LEVEL")){
				r.LEVEL=id;
				String[]d=SS.split(data, "=");
				PlayerUtil.LEVEL=Integer.parseInt(d[1]);
			}else if(data.startsWith("YUANSHI")){
				r.YUANSHI=id;
				String[]d=SS.split(data, "=");
				PlayerUtil.YUANSHI=Integer.parseInt(d[1]);
			}else if(data.startsWith("X")){
				r.X=id;
				String[]d=SS.split(data, "=");
				PlayerUtil.X=Integer.parseInt(d[1]);
			}else if(data.startsWith("Y")){
				r.Y=id;
				String[]d=SS.split(data, "=");
				PlayerUtil.Y=Integer.parseInt(d[1]);
			}
			s.setValue(240);
		}
		}catch(Exception ex){
			ex.printStackTrace();
			newLoad();
		}
	}
	void newLoad(){
		try{
			System.out.println("�µ���");
			RMS = RecordStore.openRecordStore(RMS$NAME, true);
			r.FOOD_COUNT=RMSUtil.writeString(RMS, "FOOD=10");
			r.LEVEL=RMSUtil.writeString(RMS, "LEVEL=1");
			r.YUANSHI=RMSUtil.writeString(RMS, "YUANSHI=1000");
			r.X=RMSUtil.writeString(RMS, "X=60");
			r.Y=RMSUtil.writeString(RMS, "Y=60");
			r.ANB_LEVEL=RMSUtil.writeString(RMS, "ANB_LEVEL=1");
			r.ANB_LIFE=RMSUtil.writeString(RMS, "ANB_LIFE=600");
			r.TRAVELER_LEVEL=RMSUtil.writeString(RMS, "TRAV_LEVEL=1");
			r.TRAVELER_LIFE=RMSUtil.writeString(RMS, "TRAV_LIFE=600");
			r.WD_LEVEL=RMSUtil.writeString(RMS, "WD_LEVEL=1");
			r.WD_LIFE=RMSUtil.writeString(RMS, "WD_LIFE=600");
			r.KY_LEVEL=RMSUtil.writeString(RMS, "KY_LEVEL=1");
			r.KY_LIFE=RMSUtil.writeString(RMS, "KY_LIFE=600");
			r.LS_LEVEL=RMSUtil.writeString(RMS, "LS_LEVEL=1");
			r.LS_LIFE=RMSUtil.writeString(RMS, "LS_LIFE=600");
		}catch(Exception ex){
			
		}
	}
	void eRMS(){
		
	}
	public void delCfg(){
		RMSUtil.delRMS(RMS$NAME);
	}

}
