package util;

import java.util.Vector;

public class GameOpe {
public static Vector ENEMY = new Vector();
public static Vector GAMEOBJ = new Vector();
}
