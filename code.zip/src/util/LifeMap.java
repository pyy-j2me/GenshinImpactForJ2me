package util;

import java.util.Hashtable;

public class LifeMap {
	public static  Hashtable LIFE = new Hashtable();
	static{
		LIFE.put(new Integer(1), new Integer(600));
		LIFE.put(new Integer(2), new Integer(900));
		LIFE.put(new Integer(3), new Integer(1400));
		LIFE.put(new Integer(4), new Integer(1800));
		LIFE.put(new Integer(5), new Integer(2100));
		LIFE.put(new Integer(6), new Integer(2600));
		LIFE.put(new Integer(7), new Integer(3200));
		LIFE.put(new Integer(8), new Integer(3600));
		LIFE.put(new Integer(9), new Integer(4200));
		LIFE.put(new Integer(10), new Integer(4600));
		LIFE.put(new Integer(12), new Integer(5000));
		LIFE.put(new Integer(13), new Integer(5600));
		LIFE.put(new Integer(14), new Integer(6600));
		LIFE.put(new Integer(15), new Integer(8600));
		
	}
	
}
