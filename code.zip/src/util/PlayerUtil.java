package util;

public class PlayerUtil {
	public static int LEVEL;
	public static int YUANSHI;
	public static int FOOD_COUNT;
	public static int X,Y;
}
