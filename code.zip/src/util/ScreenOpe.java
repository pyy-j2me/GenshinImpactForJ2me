package util;

public class ScreenOpe {
public static int sx,sy;
}
