package util;

public class Tmp {
public static int SX,SY;
}
