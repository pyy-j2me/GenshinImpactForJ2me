package util.gra;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

import util.ScreenOpe;

public class PAUSE {
	public Sprite sp;
	public PAUSE(){
		try{
			sp=new Sprite(Image.createImage("/obj/pause.png"));
			
			sp.setRefPixelPosition(220,300);
			sp.setVisible(true);
		}catch(Exception ex){
			
		}
	}
}
