package util.gra;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

import util.ScreenOpe;

public class PM {
	public Sprite pm;
	public PM(){
		try{
			pm=new Sprite(Image.createImage("/pm.png"));
			
			pm.setRefPixelPosition(ScreenOpe.sx-40,ScreenOpe.sy-40);
			pm.setVisible(true);
		}catch(Exception ex){
			
		}
	}
}
