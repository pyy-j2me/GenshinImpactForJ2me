/**
 * rms���߰�
 */
package util.rms;

import javax.microedition.rms.*;
/**
 * 
 * @author peiyi
 * @version 2.0
 * <h1>RMS���߰�</h1>
 * �ṩRMS���ʵĹ���
 */
public class RMSUtil {
	/**
	 * �򿪼�¼��
	 * @param name ��¼������
	 * @return ��¼��
	 */
	public static RecordStore openARMS(String name){
		RecordStore rs = null;
		if(name.length()>32){
			return null;
		}
		try {
			rs = RecordStore.openRecordStore(name, true);
		} catch (RecordStoreFullException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RecordStoreNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			return rs;
		}
	}
	public static RecordStore openERMS(String name){
		RecordStore rs = null;
		if(name.length()>32){
			return null;
		}
		try {
			rs = RecordStore.openRecordStore(name, false);
		} catch (RecordStoreFullException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RecordStoreNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RecordStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			return rs;
		}
	}
	public static boolean delRMS(String name){
		if(name.length()>32){
			return false;
		}
		try{
			RecordStore.deleteRecordStore(name);
		}catch(Exception e){return false;}
		return true;
	}
	public static String readString(RecordStore rs,int id){
		try{
			byte[]b=rs.getRecord(id);
			return (new String(b));
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	public static String readString(RecordStore rs,int id,String type){
		try{
			byte[]b=rs.getRecord(id);
			return (new String(b,type));
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	public static  int readInt(RecordStore rs , int id){
		int result = Integer.MIN_VALUE;
		try{
			result = Integer.parseInt(readString(rs,id));
		}catch(Exception ex){
			
		}
		return result;
	}
	public static int writeString(RecordStore rs ,String data){
		byte[]b=data.getBytes();
		int id=-1;
		try{
			id = rs.addRecord(b,0, b.length);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return id;
	}
	public static void setString(RecordStore rs ,int id,String data){
		byte[]b=data.getBytes();
		try{
			rs.setRecord(id, b, 0, b.length);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	public static int writeInt(RecordStore rs ,int i){
		byte[]b=(new Integer(i)).toString().getBytes();
		int id=-1;
		try{
			id = rs.addRecord(null,0, b.length);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return id;
	}
	public static void setInt(RecordStore rs ,int id,int i){
		setString(rs,id,(new Integer(i).toString()));
	}
	
}
