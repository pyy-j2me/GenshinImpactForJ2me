package util.role;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

import util.GameOpe;

public class Anb extends Man {
	private boolean fly=false;
	public boolean arr=false;
	private boolean skill=false;
	at aat;
	public Sprite rabbit;
	s ski;
	public Anb(){
		super("/role/anb.png");
		try{
			arrow = new Sprite(Image.createImage("/obj/farrow.png"),30,30);
			arrow.defineReferencePixel(15, 15);
			arrow.setVisible(false);
			aat=new at();
			rabbit = new Sprite(Image.createImage("/role/rabbit.png"),100,100);
			rabbit.setVisible(false);
			rabbit.defineReferencePixel(50, 50);
			rabbit.setRefPixelPosition(120, 160);
			
			ski=new s();
		}catch(Exception ex){
			
		}
	}
	public void setDir(int dir){
		this.dir=dir;
		if(!arr){
		if(fly){
			if(dir==Man.NORTH){
				role.setFrame(11);
			}else if(dir==Man.SOUTH){
				role.setFrame(3);
			}else if(dir==Man.WEST){
				role.setFrame(7);
			}else if(dir==Man.EAST){
				role.setFrame(15);
			}
			}else if(!fly){
				if(dir==Man.NORTH){
					role.setFrame(8);
				}else if(dir==Man.SOUTH){
					role.setFrame(0);
				}else if(dir==Man.WEST){
					role.setFrame(4);
				}else if(dir==Man.EAST){
					role.setFrame(12);
				}
			}
		}
	}
	
	public void attack() {
		arr=true;
		// TODO Auto-generated method stub
		aat.action();
	}
	
	public void die() {
		// TODO Auto-generated method stub

	}

	public void walk() {
		
	}
	public ArrowFire af = new ArrowFire(true);
	public void skill() {
		skill=true;
		
		ski.action();

	}
	
	public void skill2(){
		
	}
	public void fly() {
		if(fly){
			Man.SPEED=5;
			fly=!fly;
			returnDIR();
		}else{
			Man.SPEED=10;
			fly=!fly;
			returnDIR();
		}

	}
	protected void returnDIR(){
		if(fly){
			if(dir==Man.NORTH){
				role.setFrame(11);
			}else if(dir==Man.SOUTH){
				role.setFrame(3);
			}else if(dir==Man.WEST){
				role.setFrame(7);
			}else if(dir==Man.EAST){
				role.setFrame(15);
			}
			}else if(!fly){
				if(dir==Man.NORTH){
					role.setFrame(8);
				}else if(dir==Man.SOUTH){
					role.setFrame(0);
				}else if(dir==Man.WEST){
					role.setFrame(4);
				}else if(dir==Man.EAST){
					role.setFrame(12);
				}
			}
	}
	public boolean isSkill() {
		return skill;
	}
	public void setSkill(boolean skill) {
		this.skill = skill;
	}
	public Sprite arrow;
	
	class at extends Thread{
		int index;
		int[]seq;
		public void action(){
			arr=true;
			if(dir==Man.NORTH){
				index=1;
				arrow.setRefPixelPosition(120, 145);
				arrow.setFrame(index);
				seq=new int[]{
						9,9,10,10,10,8
				};
				
			}else if(dir==Man.SOUTH){
			index=3;
			arrow.setRefPixelPosition(120, 175);
			arrow.setFrame(index);
			seq=new int[]{
					1,1,2,2,2,0
			};
			
			}else if(dir==Man.WEST){
				index=2;
				arrow.setRefPixelPosition(105, 160);
				arrow.setFrame(index);
				seq=new int[]{
						5,5,6,6,6,4
				};
				
			}else if(dir==Man.EAST){
			index=0;
			arrow.setRefPixelPosition(135, 160);
			arrow.setFrame(index);
			seq=new int[]{
					13,13,14,14,14,12
			};
			
			}
			for(int i=0;i<seq.length;i++){
				System.out.println("---"+seq[i]);
			}
			role.setFrameSequence(seq);
			new Thread(this).start();
		}
		private void co(){
		for(int i=0;i<GameOpe.ENEMY.size();i++){
			GameObj go = (GameObj) GameOpe.ENEMY.elementAt(i);
			if(go instanceof QQRen){
				QQRen qqr=(QQRen) go;
				if(arrow.collidesWith(qqr.getSP(), false)){
					System.out.println("����");
					arr=false;
					arrow.setVisible(false);
					qqr.setLife(qqr.getLife()-50);
					if(qqr.getLife()<=0){
						System.out.println("����������");
						qqr.setPaintable(false);
					}
				}
			}
		}
		}
		
		public void run(){
			for(int i=0;i<seq.length;i++){
				role.nextFrame();
				
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					
				}
			}
			role.setFrameSequence(null);
			returnDIR();
			System.out.println("�����ʼ");
			arrow.setVisible(true);
			int x0=arrow.getRefPixelX();
			int y0=arrow.getRefPixelY();
			arrow.setRefPixelPosition(x0, y0);
			for(int i=0;i<8;i++){
				if(dir==Man.NORTH){
					y0-=20;
					arrow.setRefPixelPosition(x0, y0);
				}else if(dir==Man.SOUTH){
					y0+=20;
					arrow.setRefPixelPosition(x0, y0);
				}else if(dir==Man.EAST){
					x0+=20;
					arrow.setRefPixelPosition(x0, y0);
				}else if(dir==Man.WEST){
					x0-=20;
					arrow.setRefPixelPosition(x0, y0);
				}
				
				co();
				System.out.println("����");
				try{Thread.sleep(50);}catch(Exception cykablyat){}
			}
			System.out.println("�������");
			arr=false;
			arrow.setVisible(false);
		}
	}
	class s extends Thread{
		int x0,y0;
		public void action(){
			rabbit.setVisible(true);
			rabbit.setFrame(1);
			new Thread(this).start();
		}
		int []s1={
				2,3,2,3,2,3,2,3,2,3,2,3,2,3,2	
		};
		int[]s2={
				4,5,6,5,6,5,0
		};
		int []seq={
				2,3,2,3,2,3,2,3,2,3,2,3,2,3,2,4,5,6,5,6,5
		};
		public void run(){
			x0=rabbit.getRefPixelX();
			y0=rabbit.getRefPixelY();
			cyka:for(int i=0;i<10;i++){
				if(dir==Man.NORTH){
					y0-=15;
					
				}else if(dir==Man.SOUTH){
					y0+=15;
					
				}else if(dir==Man.EAST){
					x0+=15;
					
				}else if(dir==Man.WEST){
					x0-=15;
					
				}
				rabbit.setRefPixelPosition(x0, y0);
				/*
				 * ��ײ���
				 */
				for(int i1=0;i1<GameOpe.ENEMY.size();i1++){
					GameObj go=(GameObj)GameOpe.ENEMY.elementAt(i1);
					if(go instanceof QQRen){
						QQRen qqr = (QQRen) go;
						if(rabbit.collidesWith(qqr.sp, true)){
							if(dir==Man.EAST){
								x0+=40;
							}else if(dir==Man.WEST){
								x0-=40;
							}else if(dir==Man.NORTH){
								y0-=40;
							}else if(dir==Man.SOUTH){
								y0+=40;
							}
							rabbit.setRefPixelPosition(x0, y0);
							System.out.println("����");
							break cyka;
						}
					}
				}
				try {
					Thread.sleep(90);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("�����ƶ�����");
			System.out.println("�Զ���ը");
			
			
			rabbit.setFrameSequence(s2);
			for(int a=0;a<s2.length;a++){
				rabbit.nextFrame();
				co();
				try{
					Thread.sleep(600);
				}catch(Exception ex){}
			}
			rabbit.setFrameSequence(null);
			rabbit.setVisible(false);
			skill=false;
		}
		private void co(){
			for(int i=0;i<GameOpe.ENEMY.size();i++){
				Object obj=GameOpe.ENEMY.elementAt(i);
				if(obj instanceof QQRen){
					QQRen qqr = (QQRen) obj;
					if(rabbit.collidesWith(qqr.sp, true)){
						qqr.setLife(qqr.getLife()-50);
					}
					
				}
			}
		}
		private void co2(){
			for(int i=0;i<GameOpe.ENEMY.size();i++){
				Object obj=GameOpe.ENEMY.elementAt(i);
				if(obj instanceof QQRen){
					QQRen qqr = (QQRen) obj;
					int qx=qqr.getSP().getRefPixelX();
					int qy=qqr.getSP().getRefPixelY();
					if(qqr.isPaintable()){
					if(Math.abs(qx-x0)<=200||Math.abs(qy-y0)<=200){
						
						if(qqr.isPatrol()){
						qqr.endPatrol();
						}
						qqr.seek(x0, y0);
					}
					}
					
				}
			}
		}
	}
	
}
