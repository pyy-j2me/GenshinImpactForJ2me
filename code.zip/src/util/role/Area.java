package util.role;

import java.io.IOException;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

public abstract class Area {
Sprite trigger;
String path;
public Area(String path){
	this.path=path;
	try {
		trigger = new Sprite(Image.createImage(path));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
public abstract void active();
public abstract void deactive();
}
