package util.role;

import java.io.IOException;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

import util.GameOpe;

public class ArrowFire extends Thread{
	public Sprite sp;
	public boolean able=false;
	public static final int[]SEQ={
		0,1,3,2,3,1,3,2,1,2,3,2,1,3,2,1,3,2,3,2,1
	};
	int x,y;
	boolean isPlayer;
	public ArrowFire(boolean isPlayer){
	this.isPlayer=isPlayer;
		try {
			sp=new Sprite(Image.createImage("/role/anbskill1.png"),128,128);
			sp.defineReferencePixel(64, 64);
			
			sp.setVisible(false);
			sp.setFrameSequence(SEQ);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void action(int x,int y){
		this.x=x;
		this.y=y;
		able=true;
		sp.setVisible(true);
		sp.setRefPixelPosition(x, y);
		sp.setFrameSequence(SEQ);
		this.start();
	}
	private void co(){
		for(int i=0;i<GameOpe.ENEMY.size();i++){
			GameObj go = (GameObj) GameOpe.ENEMY.elementAt(i);
			if(go instanceof QQRen){
				QQRen qqr=(QQRen) go;
				if(sp.collidesWith(qqr.getSP(), false)){
					System.out.println("����");
					qqr.setLife(qqr.getLife()-50);
					if(qqr.getLife()<=0){
						System.out.println("����������");
						qqr.setPaintable(false);
					}
				}
			}
		}
		}
	public void run(){
		try{
		for(int i=0;i<SEQ.length;i++){
			sp.nextFrame();
			if(isPlayer){
				co();
			}
			try {
				Thread.sleep(600);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		sp.setVisible(false);
		able=false;
		}catch(Exception ex){
			
		}
	}
}
