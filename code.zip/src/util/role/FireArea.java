package util.role;

public class FireArea extends Area{
	
	public FireArea(){
		super("/obj/fire.png");
	}
	public void active() {
		// TODO Auto-generated method stub
		
	}

	public void deactive() {
		// TODO Auto-generated method stub
		
	}

}
