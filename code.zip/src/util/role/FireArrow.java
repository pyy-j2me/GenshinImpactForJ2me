package util.role;

import javax.microedition.lcdui.game.Sprite;

public class FireArrow extends Thread{
	private Sprite sp;
	
	public void run(){
		
	}
	
}
