package util.role;

public interface GO {

}
