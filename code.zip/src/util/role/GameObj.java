package util.role;

public abstract class GameObj {
public abstract int getX();
public abstract int getY();
public abstract int getWidth();
public abstract int getHeight();
}
