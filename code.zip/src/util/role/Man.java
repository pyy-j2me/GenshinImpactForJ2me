package util.role;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

public abstract class Man implements Role{
	protected String p;
	public static int SPEED=5;
	public static final int NORTH=0;
	public static final int SOUTH = 1;
	public static final int EAST = 2;
	public static final int WEST = 3;
	private static int life;
	public Sprite getRole(){
		return role;
	}
	private boolean availflag;
	protected boolean fly;
	protected int dir;
	public abstract void skill();
	protected Sprite role;
	private static int LEVEL;
	public static void setLevel(int l){
		LEVEL=l;
	}
	public static int getLEVEL(){
		return LEVEL;
	}
	
	public abstract void fly();
	public Man(String p){
		this.p=p;
		try{
			role = new Sprite(Image.createImage(p),80,80);
			
			role.defineReferencePixel(40, 40);
			role.setFrame(0);
		}catch(Exception ex){
			
		}
	}
	public static  int getLife() {
		return life;
	}
	public static void setLife(int ife) {
		life = ife;
	}
	public boolean isAvailflag() {
		return availflag;
	}
	public void setAvailflag(boolean availflag) {
		this.availflag = availflag;
	}
	public int getDir() {
		return dir;
	}
	public void setDir(int dir) {
		this.dir = dir;
	}
	public boolean isFly() {
		return fly;
	}
	public void setFly(boolean fly) {
		this.fly = fly;
	}
}
