package util.role;

import javax.microedition.lcdui.game.Sprite;

public class MapItem {
	Sprite pot;
	Sprite box;
	
	
}
