package util.role;

public interface Mob {
public void setLife(int life);
public int getLife();
}
