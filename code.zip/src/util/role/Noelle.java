package util.role;

import util.GameOpe;

public class Noelle extends Man implements Runnable{
	private int []aseq;
	private at attack_THREAD = new at();
	private boolean attack=false;
	private boolean walk=false;
	private boolean fly=false;
	boolean r=true;
	public Noelle(){
		super("/role/noelle.png");
		//start();
	}
	public void start(){
		r=true;
		new Thread(this).start();
	}
	public void attack() {
		attack=true;
		attack_THREAD.action();
		
	}
	public final void stopwalk(){
		walk=false;
	}
	public void die() {
		// TODO Auto-generated method stub

	}
	
	public void run(){
		while(r){
			try{
				if(walk){
				role.nextFrame();
				}else if(attack){
					for(int i=0;i<aseq.length;i++){
						role.nextFrame();
					}
					attack=false;
					
					setDir(this.getDir());
				}else{
					
				}
				Thread.sleep(800);
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}
	public void walk() {
		// TODO Auto-generated method stub
walk=true;
	}

	public void skill() {
		// TODO Auto-generated method stub

	}
	private void as(){
		if(dir==Man.NORTH){
			
		}else if(dir==Man.SOUTH){
			
		}else if(dir==Man.EAST){
			
		}else if(dir==Man.WEST){
			
		}
	}
	public void fly() {
		// TODO Auto-generated method stub
		if(fly){
			if(dir==Man.NORTH){
				/*aseq=new int[]{
						13,13,13
				};
				role.setFrameSequence(aseq);*/
				role.setFrame(13);
			}else if(dir==Man.SOUTH){
				//aseq=new int[]{0,0,0};
				//role.setFrameSequence(aseq);
				role.setFrame(0);
			}else if(dir==Man.EAST){
				//aseq=new int[]{
				//	20,20,20	
				//};
				//role.setFrameSequence(aseq);
				role.setFrame(20);
			}else if(dir==Man.WEST){
				//aseq=new int[]{
				//	7,7,7
				//};
				//role.setFrameSequence(aseq);
				role.setFrame(7);
			}
			}else{
				
				if(dir==Man.NORTH){
					//aseq=new int[]{
					//		14,14,14
					//	};
					//	role.setFrameSequence(aseq);
					role.setFrame(14);
				}else if(dir==Man.SOUTH){
					//aseq=new int[]{
					//		1,1,1
					//	};
					//	role.setFrameSequence(aseq);
					role.setFrame(1);
					
				}else if(dir==Man.EAST){
					//aseq=new int[]{
					//		21,21,21
					//	};
					//	role.setFrameSequence(aseq);
					role.setFrame(21);
				}else if(dir==Man.WEST){
					//aseq=new int[]{
					//		8,8,8
					//	};
					//	role.setFrameSequence(aseq);
					role.setFrame(8);
				}
			}
		fly=!fly;
	}
	public void setDir(int dir){
		role.setFrameSequence(null);
		this.dir=dir;
		if(!fly){
			if(dir==Man.NORTH){
				//aseq=new int[]{
				//		13,13,13
				//};
				//role.setFrameSequence(aseq);
				role.setFrame(13);
			}else if(dir==Man.SOUTH){
				//aseq=new int[]{0,0,0};
				//role.setFrameSequence(aseq);
				role.setFrame(0);
			}else if(dir==Man.EAST){
				//walk=true;
				//aseq=new int[]{
				//	20,20,20	
				//};
				//role.setFrameSequence(aseq);
				role.setFrame(20);
			}else if(dir==Man.WEST){
				//walk=true;
				//aseq=new int[]{
				//	7,7,7
				//};
				//role.setFrameSequence(aseq);
				role.setFrame(7);
			}
	
			}else{
				
				if(dir==Man.NORTH){
					/*aseq=new int[]{
							14,14,14
						};
						role.setFrameSequence(aseq);*/
					role.setFrame(14);
				}else if(dir==Man.SOUTH){
					/*aseq=new int[]{
							1,1,1
						};
						role.setFrameSequence(aseq);*/
					role.setFrame(1);
					
				}else if(dir==Man.EAST){
					/*aseq=new int[]{
							20,22,20,22
						};
						role.setFrameSequence(aseq);*/
					role.setFrame(21);
				}else if(dir==Man.WEST){
					/*aseq=new int[]{
							7,9,7,9
						};
						role.setFrameSequence(aseq);*/
					role.setFrame(8);
				}
			}
	}
	
	/**
	 * dont use
	 */
	protected final synchronized void tmp(){
		if(dir==Man.NORTH){
			
		}else if(dir==Man.SOUTH){
			
		}else if(dir==Man.EAST){
			
		}else if(dir==Man.WEST){
			
		}
	}
	public boolean notify=false;
	class at extends Thread{
		private int[]seq;
		public void action(){
			if(dir==Man.NORTH){
				this.seq=new int[]{
						15,16,17,18,19
				};
			}else if(dir==Man.SOUTH){
				this.seq=new int[]{
					2,3,4,5,6	
				};
			}else if(dir==Man.EAST){
				this.seq=new int[]{
						23,24,24,25
				};
			}else if(dir==Man.WEST){
				this.seq=new int[]{
						10,11,11,12
				};
			}
			System.out.println("--------������ʾ");
			for(int i=0;i<seq.length;i++){
				System.out.println(seq[i]);
			}
			role.setFrameSequence(seq);
			new Thread(this).start();
		}
		public void run(){
			act();
		}
		private void co(){
			for(int i=0;i<GameOpe.ENEMY.size();i++){
				GameObj go=(GameObj)GameOpe.ENEMY.elementAt(i);
				if(go instanceof QQRen){
					QQRen qqr = (QQRen)go;
					if(role.collidesWith(qqr.getSP(), false)){
						qqr.setLife(qqr.getLife()-33);
						notify=true;
					}
				}
			}
		}
		private  void act(){
			for(int i=0;i<seq.length;i++){
				if(attack){
					if(!notify){
				role.nextFrame();
				co();
					}else{
						notify=false;
						break;
						
					}
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					
				}
				}
			}
			
			role.setFrameSequence(null);
				attack=false;
				setDir(getDir());
				System.gc();
			
			
		}
	}
	class walk extends Thread{
		public void w(){
			if(dir==Man.NORTH){
				walk=false;
			}else if(dir==Man.SOUTH){
				walk=false;
			}else if(dir==Man.EAST){
				walk=true;
				int seq[]={
						20,22,20,22,20
				};
				role.setFrameSequence(seq);
				this.start();
			}else if(dir==Man.WEST){
				walk=true;
				int seq[]={
					7,9,7,9,7
				};
				role.setFrameSequence(seq);
				this.start();
			}
		}
		public void run(){
			try{
				while(walk){
					role.nextFrame();
					Thread.sleep(500);
				}
			}catch(Exception ex){
				
			}
		}
	}
}
