package util.role;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

public class Pot extends GameObj implements GO{
Sprite cont;
private boolean burn;
boolean run=false;
public Sprite getPOT(){
	return cont;
}
public Pot(int x,int y,boolean burn){

	try{
		
		cont = new Sprite(Image.createImage("/obj/pot.png"),60,60);
		cont.defineReferencePixel(30, 30);
		cont.setRefPixelPosition(x, y);
	}catch(Exception ex){
		
	}
	this.burn=burn;
	if(burn){
		cont.setFrameSequence(act);
		new a().start();
	}else{
		cont.setFrameSequence(null);
		cont.setFrame(1);
	}
}
public boolean isBurn() {
	return burn;
}
int []act={
		0,2,0,2
	};
public void setBurn(boolean burn) {
	
	if(burn){
		cont.setFrameSequence(act);
		new a().start();
	}else{
		this.burn=false;
		cont.setFrameSequence(null);
		cont.setFrame(1);
	}
	this.burn = burn;
}
class a extends Thread{
	public void run(){
		while(burn){
			cont.nextFrame();
			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
	}
}
public int getX() {
	// TODO Auto-generated method stub
	return this.getPOT().getX();
}
public int getY() {
	// TODO Auto-generated method stub
	return this.getPOT().getY();
}
public int getWidth() {
	// TODO Auto-generated method stub
	return 60;
}
public int getHeight() {
	// TODO Auto-generated method stub
	return 60;
}
}
