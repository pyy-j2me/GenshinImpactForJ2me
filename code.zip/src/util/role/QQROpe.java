package util.role;

import java.util.Random;

import util.GameOpe;

public class QQROpe {
	/**
	 * 
	@param x
	 * ���Ͻ�x
	 * @param y
	 * ���Ͻ�y
	 * @param width
	 * ����
	 * @param height
	 * �߶�
	 * @param mount
	 * ����
	 * @param patrolrate
	 * Ѳ�ߵĸ���
	 */
	public static void addQQRenArea(int x,int y,int width,int height,int mount,int patrolrate)
	throws IllegalArgumentException{
		int patrol_num ;
		Random rnd=new Random();
		if(patrolrate==-1){
			patrol_num=1;
		}else{
			patrol_num=patrolrate;
		if(patrolrate<1){
			throw new IllegalArgumentException();
		}
		}
		//����
		for(int i=0;i<mount;i++){
			int ax;
			int ay;
			addQQR:while(true){
				ax=rnd.nextInt(x+width);
				ay=rnd.nextInt(y+height);
				if(ax>=x&&ax<=x+width&&ay>=y&&ay<=y+height){
					QQRen qqr = new QQRen(ax,ay);
					GameOpe.ENEMY.addElement(qqr);
					int t1=rnd.nextInt(patrol_num);
					if(t1==1){
						qqr.patrol(rnd.nextInt(20));
						qqr.startPatrol();
					}
					break addQQR;
				}
			}
		}
	}
}
