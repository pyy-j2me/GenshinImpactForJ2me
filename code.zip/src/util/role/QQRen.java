package util.role;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.LayerManager;
import javax.microedition.lcdui.game.Sprite;

public class QQRen extends GameObj implements Role,Mob,GO{
	Sprite sp;
	private boolean patrol;
	private boolean seeked;
	private int sx,sy;
	public void setPos(int sx,int sy){
		this.sx=sx;
		this.sy=sy;
		sp.setRefPixelPosition(sx, sy);
	}
	public int getSX(){return sx;}
	public int getSY(){return sy;}
	int mix,miy;
	int pr;
	int dir;
	private boolean paintable=true;
	LayerManager lm;
	public Sprite getSP(){
		return sp;
	}
	public QQRen(int sx,int sy,LayerManager lm){
		this.setLife(300);
		this.sx=sx;
		this.sy=sy;
		this.lm=lm;
		mix=sx;
		
		miy=sy;
		try{
			sp = new Sprite(Image.createImage("/npc/qqr.png"),80,80);
			lm.append(sp);
			sp.defineReferencePixel(40, 40);
			sp.setRefPixelPosition(sx, sy);
			this.setDir(Man.NORTH);
		}catch(Exception ex){
			
		}
	}
	private int life;
	
	public QQRen(int sx,int sy){
		this.setLife(100);
		this.sx=sx;
		this.sy=sy;
		
		mix=sx;
		miy=sy;
		try{
			sp = new Sprite(Image.createImage("/npc/qqr.png"),80,80);
			sp.defineReferencePixel(40, 40);
			sp.setRefPixelPosition(sx, sy);
			this.setDir(Man.NORTH);
		}catch(Exception ex){
			
		}
	}
	public void setDir(int dir){
		if(dir==Man.NORTH||dir==Man.SOUTH){
			sp.setFrame(2);
		}else if(dir==Man.EAST){
			sp.setFrame(1);
		}else if(dir==Man.WEST){
			sp.setFrame(0);
		}
	}
	public void patrol(int range){
		pr=range;
	}
	public void startPatrol(){
		run=true;
		this.setPatrol(run);
		new p().start();
		System.out.println("��ʼ�ƶ�");
	}
	public void endPatrol(){
		patrol=false;
		run=false;
	}
	boolean run=true;
	class p extends Thread{
		public void run(){
			while(run){
			for(int i=0;i<pr;i++){
				
				sx+=5;
				sp.setRefPixelPosition(sx, sy);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("�ƶ�����");
			for(int a=0;a<pr;a++){
				sx-=5;
				sp.setRefPixelPosition(sx, sy);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("�ƶ�����!");
			}
		}
	}
	public void attack() {
		new at().start();
		
	}
	class at extends Thread{
		int seq[]={2,2,2,3,3,3,2,2,2};
		public void run(){
			sp.setFrameSequence(seq);
			for(int i=0;i<seq.length;i++){
				sp.nextFrame();
				try {
					Thread.sleep(120);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			sp.setFrameSequence(null);
			if(dir==Man.NORTH||dir==Man.SOUTH){
				sp.setFrame(2);
			}else if(dir==Man.EAST){
				sp.setFrame(1);
			}else if(dir==Man.WEST){
				sp.setFrame(0);
			}
		}
	}
	se seek = new se();
	public void seek(int x,int y){
		seeked=true;
		seek.seek(x, y);
		
	}
	public void endSeek(){
		seeked=false;
		System.gc();
	}
	class se extends Thread{
		int x,y;
		int xt,yt;
		public void seek(int x,int y){
			this.x=x;
			this.y=y;
			xt=Math.abs(x-sx)/5;
			yt=Math.abs(y-sy)/5;
			new Thread(this).start();
		}
		public void run(){
			while(seeked){
			if(Math.abs(x-sx)>0){
				System.out.println("�����ƶ�");
				if((x-sx)>0){
					sx+=xt;
				}else if((x-sx)<0){
					sx-=xt;
				}
				sp.setRefPixelPosition(sx, sy);
			}if(Math.abs(y-sy)>0){
				System.out.println("�����ƶ�");
				if((y-sy)>0){
					sy+=yt;
				}else if((y-sy)<0){
					sy-=yt;
				}
				sp.setRefPixelPosition(sx, sy);
			}
			if(Math.abs(y-sy)==0&&Math.abs(x-sx)==0){
				endSeek();
				break;
				
			}
			}
			endSeek();
		}
	}
	class s1 extends Thread{
		final int x;
		 int l;
		s1(int x){
			this.x=x;
			l=Math.abs(sx-x)/5;
			System.out.println("�ƶ�"+l);
		}
		public void run(){
			synchronized(this){
			for(int i=0;i<l;i++){
				if((sx-x)>0){
					sx-=5;
				}else if((sx-x)<0){
					sx+=5;
				}
				sp.setRefPixelPosition(sx, sy);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			}
			
		}
	}
	class s2 extends Thread{
		 final int y;
		int l;
		s2(int y){
			this.y=y;
			l=Math.abs(sy-y)/5;
			System.out.println("�ƶ�"+l);
		}
		public void run(){
			synchronized(this){
			for(int i=0;i<l;i++){
				if((sy-y)>0){
					sy--;
				}else if((sy-y)<0){
					sy++;
				}
				sp.setRefPixelPosition(sx, sy);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			}
			
		}
		
	}
	public void die() {
		// TODO Auto-generated method stub
		
	}

	public void walk() {
		// TODO Auto-generated method stub
		
	}
	public int getLife() {
		return life;
	}
	public void setLife(int life) {
		this.life = life;
		if(life<=0){
			System.out.println("����");
			this.setPaintable(false);
			sp.setVisible(false);
		}
	}
	public boolean isPaintable() {
		return paintable;
	}
	public void setPaintable(boolean paintable) {
		this.paintable = paintable;
		if(paintable==false){
			sp.setVisible(false);
		}else{
			sp.setVisible(true);
		}
	}
	public int getX() {
		// TODO Auto-generated method stub
		return sp.getX();
	}
	public int getY() {
		// TODO Auto-generated method stub
		return sp.getY();
	}
	public int getWidth() {
		// TODO Auto-generated method stub
		return 80;
	}
	public int getHeight() {
		// TODO Auto-generated method stub
		return 80;
	}
	public boolean isPatrol() {
		return patrol;
	}
	public void setPatrol(boolean patrol) {
		this.patrol = patrol;
	}
	

}
