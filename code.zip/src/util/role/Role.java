package util.role;

public interface Role {
	public void attack();
	public void die();
	public void walk();
	
}
