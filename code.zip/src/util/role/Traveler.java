package util.role;

import java.io.IOException;
import java.util.Date;
import java.util.Random;

import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

import app.Game;

import util.GameOpe;



public class Traveler extends Man {
	public static int SPEED=5;
	private boolean a=false;
	
	private boolean attackFLAG =false;
	public Traveler(){
		super("/role/traveller.png");
		
	}
	at attack = new at();
	public void attack() {
		attack.attack();
		
		
	}
	public void skill(){
		setA(true);
		y.act();
	}
	public void die() {
		
	}
	public void fly() {
		if(!fly){
			fly=!fly;
			Man.SPEED=10;
			if(dir==Man.NORTH){
				role.setFrame(11);
			}else if(dir==Man.EAST){
				role.setFrame(15);
			}else if(dir==Man.SOUTH){
				role.setFrame(1);
			}else if(dir==Man.WEST){
				role.setFrame(5);
			}
		}else{
			fly=!fly;
			Man.SPEED=5;
		if(dir==Man.NORTH){
			role.setFrame(10);
		}else if(dir==Man.EAST){
			role.setFrame(14);
		}else if(dir==Man.SOUTH){
			role.setFrame(0);
		}else if(dir==Man.WEST){
			role.setFrame(4);
		}
		}

	}
	Sprite wind;
	public Sprite getWind(){
		return y.getACT();
	}
	ys y=new ys(role);
	public void setDir(int dir){
		role.setFrameSequence(null);
		this.dir=dir;
		if(!fly){
		if(dir==Man.NORTH){
			role.setFrame(10);
		}else if(dir==Man.EAST){
			role.setFrame(14);
		}else if(dir==Man.SOUTH){
			role.setFrame(0);
		}else if(dir==Man.WEST){
			role.setFrame(4);
		}
		}else{
			if(dir==Man.NORTH){
				role.setFrame(11);
			}else if(dir==Man.EAST){
				role.setFrame(15);
			}else if(dir==Man.SOUTH){
				role.setFrame(1);
			}else if(dir==Man.WEST){
				role.setFrame(5);
			}
		}
	}
	w walk = new w();
	boolean w = false;
	public void walk() {
		w=true;
		walk.wa();
		
	}
	public static final int speedX=45;
	public void stop(){
		w=false;
		role.setFrameSequence(null);
		this.returnDIR();
	}
	class w extends Thread{
		
		public void wa(){
			if(dir==Man.EAST){
				role.setFrameSequence(new int[]{
						19,14,19,14,19,14
				});
				new Thread(this).start();
			}else if(dir==Man.WEST){
				role.setFrameSequence(new int[]{
						9,4,9,4,9,4
				});
				new Thread(this).start();
			}
			
		}
		public void run(){
			while(w){
				
				role.nextFrame();
				try {
					Thread.sleep(20);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		}
	}
	class at extends Thread{
		int []index;
		at(){
			
			
		}
		public void attack(){
			if(dir==Man.EAST){
				int act[]={
					16,17,17,18,18	
				};
				action(act);
			}else if(dir==Man.NORTH){
				int act[]={
						13,13,12,12,13
				};
				action(act);
			}else if(dir==Man.SOUTH){
				int act[]={
					3,3,2,2,3
				};
				action(act);
			}else if(dir==Man.WEST){
				int act[]={
						6,7,7,8,8
				};
				action(act);
			}
		}
		void action(int []inde){
			role.setFrameSequence(inde);
			attackFLAG=true;
			//new co().start();
			new Thread(this).start();
		}
		public void run(){
			try {
			for(int i=0;i<4;i++){
				role.nextFrame();
				
				
					Thread.sleep(25);
				}
			}catch(Exception ex){}
	
		
			for(int i=0;i<GameOpe.ENEMY.size();i++){
				Object o=GameOpe.ENEMY.elementAt(i);
				if(o instanceof QQRen){
					QQRen qqr=(QQRen)o;
					if(role.collidesWith(qqr.getSP(), true)){
						System.out.println("����������");
						qqr.setLife(qqr.getLife()-25);
						if(qqr.getLife()<=0){
							System.out.println("����������");
							qqr.setPaintable(false);
						}
					}
					
				}
			}
			role.setFrameSequence(null);
			attackFLAG=false;
			returnDIR();
		}
	}
	public boolean getAttackFlag(){
		return attackFLAG;
	}
	protected void returnDIR(){
		if(dir==Man.NORTH){
			role.setFrame(10);
		}else if(dir==Man.EAST){
			role.setFrame(14);
		}else if(dir==Man.SOUTH){
			role.setFrame(0);
		}else if(dir==Man.WEST){
			role.setFrame(4);
		}
	}

	public boolean isA() {
		return a;
	}
	public void setA(boolean a) {
		this.a = a;
	}
	static Image ACTIMAGE;
	static{
		try {
			ACTIMAGE = Image.createImage("/role/travelerACT.png");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	class ys {
		int maxLength = 200;
		Sprite actSP=new Sprite(ACTIMAGE,60,60);
		public Sprite getACT(){
			return actSP;
		}
		int fx,fy;
		Sprite sp;
		ys(Sprite sp){
			actSP.defineReferencePixel(actSP.getWidth()/2, actSP.getHeight()/2);
		this.sp=sp;
		}
		
		
		void in(){
			if(dir==Man.EAST){
				actSP.setRefPixelPosition(140, 160);
			}else if(dir==Man.WEST){
				actSP.setRefPixelPosition(100, 160);
			}else if(dir==Man.NORTH){
				actSP.setRefPixelPosition(120, 140);
			}else if(dir==Man.SOUTH){
				actSP.setRefPixelPosition(120, 180);
			}
		}
		void act(){
			in();
			System.out.println("!1");
			if(dir==Man.EAST){
				int[]i3={
						0,0,1,1,0,0,1,1,0,0,2,2	
					};
					action(i3);
			}
			else if(dir== Man.WEST){
				int i2[]={
						0,0,1,1,0,0,1,1,0,0,3,3
				};
				action(i2);
				
			}else if(dir== Man.NORTH){
				int []i1={
						0,0,1,1,0,0,1,1,0,0,4,4
				};
				action(i1);
				
			}else if(dir==Man.SOUTH){
				int[]i={
						0,0,1,1,0,0,1,1,0,0,5,5
				};
				action(i);
			}
			}
		
		void action(int[] act){
			actSP.setVisible(true);
			actSP.setFrame(0);
			System.out.println("�߳̿�ʼ");
			new a(act,this).start();
		}
		class a extends Thread{
			int index[];
			ys y;
			a(int []index,ys y){
			this.index=index;
			this.y=y;
			}
			public void run(){
				setA(true);
				act();
				y.actSP.setFrameSequence(null);
				int cx=y.actSP.getRefPixelX();
				int cy=y.actSP.getRefPixelY();
				
				for(int i=0;i<y.maxLength;i+=10){
					if(dir==Man.NORTH){
						actSP.setFrame(4);
						cy-=i;
					}else if(dir==Man.EAST){
						actSP.setFrame(2);
						cx+=i;
					}else if(dir==Man.WEST){
						actSP.setFrame(3);
						cx-=i;
					}else if(dir==Man.SOUTH){
						actSP.setFrame(5);
						cy+=i;
					}
					co();
					y.actSP.setRefPixelPosition(cx, cy);
					
					try {
						Thread.sleep(20);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				//��ײ���
				
				a=false;
				
			}
			private void act(){
				y.actSP.setFrameSequence(index);
				for(int i=0;i<index.length;i++){
					System.out.println("����");
					y.actSP.nextFrame();
					
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
			private void co(){
				for(int i=0;i<GameOpe.ENEMY.size();i++){
					GameObj go = (GameObj)GameOpe.ENEMY.elementAt(i);
					if(go instanceof QQRen){
						QQRen qqr = (QQRen) go;
						if(actSP.collidesWith(qqr.sp, true)){
							actSP.setVisible(false);
							a=false;
							qqr.setLife(qqr.getLife()-50);
						}
					}
				}
				
				
			}
			private void coqqr(QQRen qqr){
				//act whxy
				System.out.println("���");
				int lx = actSP.getRefPixelX()-actSP.getWidth()/2;
				int ly = actSP.getRefPixelY()-actSP.getHeight()/2;
				int aw = actSP.getWidth();
				int ah  = actSP.getHeight();
				//qqrwhxy
				int qqx=qqr.getSP().getRefPixelX()-qqr.getSP().getWidth()/2;
				int qqy = qqr.getSP().getRefPixelY()-qqr.getSP().getHeight()/2;
				int qqw = qqr.getSP().getWidth();
				int qqh= qqr.getSP().getHeight();
				if(Actor.isCollidingWith(lx, ly, aw, ah, qqx, qqy, qqw, qqh)){
					System.out.println("����");
					qqr.setLife(qqr.getLife()-75);
				}
			}
			
		}
		
		
	}
	private void coll(){
		for(int i=0;i<GameOpe.ENEMY.size();i++){
			System.out.println(new Date()+"=:�������==========");
			GameObj mob = (GameObj) GameOpe.ENEMY.elementAt(i);
			//�ο�X
			int rx=role.getRefPixelX();
			
			//�ο���Y
			int ry=role.getRefPixelY();
			System.out.println("\t��Ҳο�����"+rx+","+ry);
			//role�����Ͻ�
			
			int []r1={
				Game.x,Game.y,Game.x+80,Game.y+80
			};
			
			System.out.println("\t���Ͻ�:"+Game.x+","+Game.y);
			//���ȸ߶�
			int rw = role.getWidth();
			int rh = role.getHeight();
			System.out.println("\t��ҿ���"+rw+","+rh);
			System.out.println("\t------��������---------");
			System.out.println("\t"+"������������"+mob.getX()+","+mob.getY());
			System.out.println("\t"+"���������С"+mob.getWidth()+","+mob.getHeight());
			int r2[]={
				mob.getX(),mob.getY(),mob.getX()+mob.getWidth(),mob.getY()+mob.getHeight()	
			};
			if(Actor.IsRectCrossing(r1, r2)){
				System.out.println(new Date()+"�ɹ���ײ");
				/*if(mob instanceof QQRen){
					QQRen qqr = (QQRen)mob;
					System.out.println("����");
					qqr.setLife(qqr.getLife()-25);
					if(qqr.getLife()<=0){
						System.out.println("����������");
						qqr.setPaintable(false);
					}
				}else if(mob instanceof Pot){
					Pot po=(Pot)mob;
					po.setBurn(!po.isBurn());
					System.out.println("��");
				}*/
			}
		}
	}
	
	private void co$a(){
		for(int i=0;i<GameOpe.ENEMY.size();i++){
			System.out.println(new Random());
			GameObj mob = (GameObj) GameOpe.ENEMY.elementAt(i);
			//System.out.println("�������----------------"+new Date());
			//�ο�X
			int rx=role.getRefPixelX();
			
			//�ο���Y
			int ry=role.getRefPixelY();
			//System.out.println("��Ҳο�����"+rx+","+ry);
			//role�����Ͻ�
			
		
			//System.out.println("���Ͻ�:"+Game.x+","+Game.y);
			//���ȸ߶�
			int rw = role.getWidth();
			int rh = role.getHeight();
			//System.out.println("��ҿ���"+rw+","+rh);
			if(mob instanceof QQRen){
				{
				QQRen qqr = (QQRen )mob;
				
				
			
				//�����˵����Ͻ�
				int qqlx = qqr.getSP().getX();
				int qqly = qqr.getSP().getY();
				System.out.println("-----���������Ͻ�"+qqlx+","+qqly);
				int qqw = qqr.getSP().getWidth();
				int qqh = qqr.getSP().getHeight();
				
				if(Actor.isCollidingWith(Game.x,Game.y,rw,rh, qqlx, qqly, qqw, qqh)){
					System.out.println("����");
					qqr.setLife(qqr.getLife()-25);
					if(qqr.getLife()<=0){
						System.out.println("����������");
						qqr.setPaintable(false);
					}
				}
				}
			}/*else if(mob instanceof Pot){
				Pot p = (Pot)mob;
				//����Ŀ��ȸ߶����Ͻ�
				int plx = p.getPOT().getRefPixelX()-p.getPOT().getWidth()/2;
				int ply = p.getPOT().getRefPixelY()-p.getPOT().getHeight()/2;
				int pw = p.getPOT().getWidth();
				int ph = p.getPOT().getHeight();
				if(Actor.isCollidingWith(Game.x, Game.y, rw, rh, plx, ply, pw, ph)){
					p.setBurn(!p.isBurn());
					System.out.println("��");
				}
					}*/
		}
	}
	private void coa(){
		for(int i=0;i<GameOpe.ENEMY.size();i++){
			GameObj mob = (GameObj) GameOpe.ENEMY.elementAt(i);
	if(mob instanceof QQRen){
		
		QQRen q = (QQRen) mob;
		System.out.println(q.getSP().collidesWith(role, true));
				if(q.getSP().collidesWith(role, false)){
					System.out.println("����");
					q.setLife(q.getLife()-25);
				}else if(mob instanceof Pot){
					System.out.println(role.collidesWith(q.getSP(), false));
					Pot p = (Pot)mob;
					if(p.getPOT().collidesWith(role, false));
					System.out.println("��������");
					p.setBurn(!p.isBurn());
				}
			}
			}
	}
	class co extends Thread{
		co(){
			System.out.println("��ײ���");
		}
		public void run(){
			while(attackFLAG){
				for(int i=0;i<GameOpe.ENEMY.size();i++){
					GameObj mob = (GameObj) GameOpe.ENEMY.elementAt(i);
			if(mob instanceof QQRen){
				
				QQRen q = (QQRen) mob;
				System.out.println(role.collidesWith(q.getSP(), false));
						if(role.collidesWith(q.getSP(), false)){
							System.out.println("����");
							q.setLife(q.getLife()-25);
						}else if(mob instanceof Pot){
							System.out.println(role.collidesWith(q.getSP(), false));
							Pot p = (Pot)mob;
							if(role.collidesWith(p.getPOT(), false));
							System.out.println("��������");
							p.setBurn(!p.isBurn());
						}
					}
					}
			}
		}
	}
}
